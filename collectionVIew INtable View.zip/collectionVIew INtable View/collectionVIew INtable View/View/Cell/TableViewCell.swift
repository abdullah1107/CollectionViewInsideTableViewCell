//
//  TableViewCell.swift
//  collectionVIew INtable View
//
//  Created by Arman Akash on 6/1/20.
//  Copyright © 2020 Arman Akash. All rights reserved.
//

import UIKit


class TableViewCell: UITableViewCell {
    
    var counter:Int?
    
    @IBOutlet weak var catagoryLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var name = [String]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionView.dataSource = self
        collectionView.delegate = self
        counter = 0
        name.removeAll()
        
    }
 
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    public func configuredata(with json:BookCategory){
            
        counter = json.book?.count
        
        for i in 0..<json.book!.count {
            name.append(json.book![i].bookName!)
           
        }

    }
    
}

extension TableViewCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //print(bookcategory.count)
        
        return counter ?? 0
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath as IndexPath) as! CollectionViewCell
        
       
        cell.nameLabel.text = name[indexPath.row]
      
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 146, height: 186)
    }
}
