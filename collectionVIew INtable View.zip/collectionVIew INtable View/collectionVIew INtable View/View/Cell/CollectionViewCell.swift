//
//  CollectionViewCell.swift
//  collectionVIew INtable View
//
//  Created by Arman Akash on 6/1/20.
//  Copyright © 2020 Arman Akash. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
   
    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
   
}
