//
//  ViewController.swift
//  collectionVIew INtable View
//
//  Created by Arman Akash on 6/1/20.
//  Copyright © 2020 Arman Akash. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UIViewController{

  var bookcategory = [BookCategory]()
    

    
    @IBOutlet weak var tableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        loaddatafromServer()
    }
    
    let headers: HTTPHeaders = [
           "Accept": "application/json"
       ]
       
       func loaddatafromServer(){
           AF.request("https://api.myjson.com/bins/xdwpq", headers: headers).response { response in
               
               //debugPrint(response)
               DispatchQueue.main.async() {
                   
                   let personitems = JSON(response.value as Any)
                   //print(personitems)
                   
                   for personitem in personitems{
                       //print(personitem.0)
                      // print(personitem.1)
                       let bookmodel = BookCategory(personitem.1)
                       //print(personmodel)
                       self.bookcategory.append(bookmodel)
                   }
                   
                   self.tableView.reloadData()
                   
                   
               }
               
           }.resume()
       }
       
}
extension ViewController:UITableViewDelegate, UITableViewDataSource{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bookcategory.count//CategoryArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = self.tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! TableViewCell
          
        cell.configuredata(with: bookcategory[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 240
    }



}

